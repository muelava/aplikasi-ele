<nav class="navbar navbar-expand-lg navbar-dark bg-transparent <?php echo e(($active === 'courses' || $active === 'register') ? 'bg-premiere-2' : ''); ?> px-5 position-fixed w-100" style="top: 0;">
    <div class="container-fluid">
      <a class="navbar-brand d-flex align-items-center" href="/">
        <img src="<?php echo e(asset('/img/logo_bina_ikhwani.png')); ?>" alt="" width="50" class="d-inline-block align-text-top">
        SMP SMK Bina Ikhwani
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mx-auto">
          
        </ul>
                  
          <ul class="ms-auto navbar-nav">
            <?php if(auth('admin')->check() || auth('guru')->check() || auth('siswa')->check()): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle text-capitalize" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Welcome, 
                <?php if(auth('admin')->check()): ?>
                <?php echo e(auth('admin')->user()->nama); ?>

                <?php elseif(auth('guru')->check()): ?>
                <?php echo e(auth('guru')->user()->nama); ?>

                <?php elseif(auth('siswa')->check()): ?>
                <?php echo e(auth('siswa')->user()->nama); ?>

                <?php endif; ?>
              </a>  
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li>
                  <p class="dropdown-item text-capitalize"><i class="bi bi-person"></i> Dashboard</p>
                </li>
                <li><a class="dropdown-item" href="<?php echo e(asset('/courses')); ?>"><i class="bi bi-layout-text-sidebar-reverse"></i> My Course</a></li>
                <li><hr class="dropdown-divider"></li>
                <li>
                  <form action="/logout" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="dropdown-item text-danger"><i class="bi bi-box-arrow-right"></i> Logout</button>
                  </form>
                </li>
              </ul>
            </li>
            <?php else: ?>
            <li class="nav-item">
              <a class="nav-link" href="/login">Login</a>
            </li>
            <?php endif; ?>
          </ul>
      </div>
    </div>
  </nav><?php /**PATH C:\laragon\www\aplikasi-ele\resources\views/partials/navbar.blade.php ENDPATH**/ ?>