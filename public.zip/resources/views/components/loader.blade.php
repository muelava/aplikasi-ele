<div id="loader" class="text-white d-none" style="position:fixed; top:0; bottom:0; left:0; right:0; background-color:#00000040; display:flex; justify-content:center; align-items:center">
    <img src="{{ asset('/admin/assets/animations/spinner.svg') }}" width="100" alt="spinner.svg">
</div>
