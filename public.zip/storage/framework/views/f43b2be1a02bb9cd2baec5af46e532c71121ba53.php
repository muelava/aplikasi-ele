
<?php $__env->startSection('title', 'Tugas'); ?>
<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/pickers/flatpickr/flatpickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/core/menu/menu-types/vertical-menu.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/plugins/forms/pickers/form-flat-pickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-header row">

                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0"><a href="<?php echo e(route('guru-materi')); ?>"><?php echo e($materi->kelas->kelas); ?></a></h2>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active">
                                    <a href="<?php echo e(route('guru-materi')); ?>"><?php echo e($materi->mata_pelajaran->mapel); ?></a>
                                </li>
                                <li class="breadcrumb-item active">
                                    <a href="<?php echo e(route('guru-materi')); ?>"><?php echo e($materi->materi); ?></a>
                                </li>
                                <li class="breadcrumb-item active">
                                    Tugas
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="row" id="table-hover-row">
                <div class="col-12">

                    <div class="card">

                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php $__errorArgs = ['tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <?php if(empty($tugas)): ?>
                            <div class="card-header">
                                <h6>Belum ada Tugas untuk materi <b>"<?php echo e($materi->materi); ?>"</b>.</h6>
                            </div>
                        <?php else: ?>
                            <div class="card-header">
                                <h6>Tugas:</h6>
                                <p>created <?php echo e($tugas->created_at->diffForHumans()); ?></p>
                                <div class="col-12">
                                    <article>
                                        <?php echo e($tugas->tugas); ?>

                                    </article>
                                    <div class="mt-2">
                                        <label for="">File Tugas</label>
                                        <p>
                                            <?php if(empty($tugas->dok_tugas)): ?>
                                                <p>Tidak ada file tugas</p>
                                            <?php else: ?>
                                                <a href="<?php echo e(asset('files/tugas/' . $tugas->dok_tugas)); ?>" target="_blank"><?php echo e($tugas->dok_tugas); ?></a>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="mt-2">
                                        <label for="">Waktu berakhir tugas</label>
                                        <p><?php echo e(date('d M Y H:i', strtotime($tugas->expired_tugas))); ?> WIB <span id="expired-tugas" class="text-warning"></span></p>
                                    </div>
                                </div>
                                <hr>
                            </div>
                        <?php endif; ?>

                    </div>

                    <div class="card">
                        <div class="card-body">
                            <?php if(empty($sub_tugas)): ?>
                                <button class="btn btn-primary mr-2" data-toggle="modal" data-target="#modal-tambah-tugas"><i data-feather="plus"></i>
                                    Submit Tugas</button>
                            <?php else: ?>
                                <p id="reminder-text" class="px-2 text-center">Kamu bisa lakukan perubahan tugas sebelum
                                    <span id="time-limit" class="text-warning"></span>
                                </p>
                                <form id="form-submit-tugas" action="/courses/materi/tugas/ubah/<?php echo e($sub_tugas->id); ?>" method="POST" enctype='multipart/form-data' class="card-header pt-0" style="gap:1rem">

                                    <?php echo e(csrf_field()); ?>

                                    <div id="input-ubah-tugas" class="form-group col-12 px-0">
                                        <label>Jawaban Tugas</label>
                                        <textarea class="form-control mb-2" name="tugas" rows="10" required><?php echo e($sub_tugas->tugas ? $sub_tugas->tugas : old('tugas')); ?></textarea>
                                        <div class="form-group">
                                            <label for="customFile">Dokumen Tugas</label>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="customFile" data-dok="tugas_update" value="<?php echo e(asset('files/tugas/' . $sub_tugas->dok_tugas ? $sub_tugas->dok_tugas : '')); ?>" name="dok_tugas">
                                                <label class="custom-file-label" for="customFile" data-label="tugas_update"><?php echo e($sub_tugas->dok_tugas ? $sub_tugas->dok_tugas : ''); ?></label>
                                                <div class="form-text">Diizinkan PDF, maksimal 4 MB</div>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-end" style="gap:1rem">
                                            <button type="submit" id="btn-perbarui" class="btn btn-primary">Perbarui</button>
                                        </div>
                                    </div>

                                </form>
                            <?php endif; ?>
                        </div>
                    </div>


                </div>
            </div>
            
        </div>
    </div>

    <!-- Modal tambah -->
    <div class="modal fade text-left" id="modal-tambah-tugas" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel33">Submit tugas <b><?php echo e($materi->materi); ?></b></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="/courses/materi/tugas/tambah/<?php echo e($tugas->id); ?>" method="POST" enctype='multipart/form-data'>

                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <label>Tugas</label>
                        <div class="form-group">
                            <input type="text" class="form-control" required value="<?php echo e($tugas->tugas); ?>" disabled />
                        </div>
                        <label>Jawaban Tugas</label>
                        <div class="form-group">
                            <textarea class="form-control <?php $__errorArgs = ['tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tugas" cols="30" rows="10" required><?php echo e(old('tugas')); ?></textarea>
                            <?php $__errorArgs = ['tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="customFile">Dokumen Tugas</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="customFile" name="dok_tugas" required>
                                <label class="custom-file-label" for="customFile">Pilih file</label>
                                <div class="form-text">Diizinkan PDF, maksimal 4 MB</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /Modal tambah -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/js/pickers/flatpickr/flatpickr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

    <?php if($tugas): ?>
        <script>
            let expired_tugas = '<?php echo e($tugas->expired_tugas); ?>';

            let dateExpiredTugas = new Date(expired_tugas),
                getTimeExTugas = dateExpiredTugas.getTime(),
                decTimeExTugas = getTimeExTugas - new Date().getTime()
            resultExpiredTugas = decTimeExTugas / 1000

            if (resultExpiredTugas < 1) {
                $('#expired-tugas').text('(Waktu pengumpulan tugas telah berakhir)')
                let sub_tugas = '<?php echo e($sub_tugas); ?>'
                if (sub_tugas.length) {
                    document.querySelector('#reminder-text').textContent = 'Tugas kamu sudah terkumpul.';
                    document.querySelector('form#form-submit-tugas').classList.add('d-none')
                } else {
                    $('.card-body').html('<p class="text-center text-danger">Kamu tidak mengumpulkan tugas</p>')
                }
            } else {
                function expiredTugas(duration, displayExpiredTugas) {
                    var start = Date.now(),
                        diff,
                        hours,
                        minutes,
                        seconds;

                    function timer() {
                        diff = duration - (((Date.now() - start) / 1000) | 0);

                        hours = (diff / 3600) | 0;
                        minutes = (diff / 60) % 60 | 0;
                        seconds = (diff % 60) | 0;

                        hours = hours < 10 ? "0" + hours : hours;
                        minutes = minutes < 10 ? "0" + minutes : minutes;
                        seconds = seconds < 10 ? "0" + seconds : seconds;

                        $(displayExpiredTugas).text('(' + hours + ' : ' + minutes + ' : ' + seconds + ')')

                        if (diff <= 0) {
                            // start = Date.now() + 1000;
                            clearInterval(runTime)
                        }
                    };
                    timer();
                    let runTime = setInterval(timer, 1000);
                }
                let displayExpiredTugas = '#expired-tugas';
                expiredTugas(resultExpiredTugas, displayExpiredTugas);
            }
        </script>
    <?php endif; ?>

    <?php if($sub_tugas): ?>
        <script>
            // BEGIN: countdown ubah tugas
            let created_at = '<?php echo e($sub_tugas->created_at); ?>';
            let dateCurrent = new Date(created_at),
                getTime = dateCurrent.getTime(),
                someTime = getTime + 1800000, //1800000 (30mnt)
                decTime = someTime - new Date().getTime()
            resultTmer = decTime / 1000

            if (resultTmer < 1) {
                document.querySelector('#reminder-text').textContent = 'Tugas kamu sudah terkumpul.';
                $('#reminder-text').after(
                    `<div class="text-center"><a href="/files/tugas/<?php echo e($sub_tugas->dok_tugas); ?>" target="_blank"><?php echo e($sub_tugas->dok_tugas); ?></a><p class="text-center text-success mt-1">Submited!</p></div>`
                )
                document.querySelector('#btn-perbarui').setAttribute('disabled', true)
                document.querySelector('form#form-submit-tugas').classList.add('d-none')
            } else {
                function startTimer(duration, display) {
                    var start = Date.now(),
                        diff,
                        hours,
                        minutes,
                        seconds;

                    function timer() {
                        diff = duration - (((Date.now() - start) / 1000) | 0);

                        hours = (diff / 3600) | 0;
                        minutes = (diff / 60) % 60 | 0;
                        seconds = (diff % 60) | 0;

                        hours = hours < 10 ? "0" + hours : hours;
                        minutes = minutes < 10 ? "0" + minutes : minutes;
                        seconds = seconds < 10 ? "0" + seconds : seconds;

                        display.textContent = hours + ":" + minutes + ":" + seconds + " Detik";

                        if (diff <= 0) {
                            // start = Date.now() + 1000;
                            clearInterval(runTime)
                        }
                    };
                    timer();
                    let runTime = setInterval(timer, 1000);
                }
                var display = document.querySelector('#time-limit');
                startTimer(resultTmer, display);
            }
            // END: countdown ubah tugas
        </script>
    <?php endif; ?>

    <script src="<?php echo e(asset('/admin/assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('courses.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasi-ele\resources\views/courses/pages/materi-tugas.blade.php ENDPATH**/ ?>