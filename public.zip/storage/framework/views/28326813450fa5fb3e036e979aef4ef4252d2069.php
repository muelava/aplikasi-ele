<footer class="mt-5">
    <!-- Grid column -->
    <div class="col-md-5 text-center mx-auto py-5 ">
        <!-- Links -->
        <h4 class="text-uppercase fw-bold mb-5">SMP-SMK Bina Ikhwani</h4>
            <p class="mb-2">
              <a href="#" class="text-reset text-decoration-none">Jl.Cereme Rt.01 Rw.03 Ds. Sinarsari Kec. Dramaga Bogor</a>
            </p>
        </div>
        <!-- Grid column -->
        <div class=" mb-5 text-center" style="font-size:1.5em">
            <a href="#" class="text-decoration-none text-light">
                <i class="bi bi-instagram"></i>
            </a>
            <a href="#" class="text-decoration-none px-3 text-light">
                <i class="bi bi-facebook"></i>
            </a>
            <a href="#" class="text-decoration-none text-light">
                <i class="bi bi-twitter"></i>
            </a>
        </div>
        <hr>
        <small class="text-center d-block mb-0 py-3">
          <a href="#" class="text-reset text-decoration-none">Copyright © SMP SMK Bina Ikhwati</a>
        </small>

</footer>
<script src="/js/script.js"></script><?php /**PATH C:\laragon\www\aplikasi-ele\resources\views/partials/footer.blade.php ENDPATH**/ ?>