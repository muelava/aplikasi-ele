
<?php $__env->startSection('title', 'Jadwal'); ?>
<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/pickers/flatpickr/flatpickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/core/menu/menu-types/vertical-menu.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/plugins/forms/pickers/form-flat-pickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-header row">

                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0">Jadwal Pelajaran</h2>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="row" id="table-hover-row">
                <div class="col-12">
                    <div class="card">
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        <div class="card-body">
                            <?php if($jadwal): ?>
                                <label for="">Jadwal Pelajaran Saat ini:</label>
                                <br>
                                <a href="<?php echo e(asset('files/jadwal/' . $jadwal->jadwal)); ?>" target="_blank" rel="noopener noreferrer">Lihat <?php echo e($jadwal->jadwal); ?></a>
                                <br>
                                <br>
                                <br>

                                <p>Perbarui Jadwal</p>
                                <form action="/administrator/jadwal-pelajaran/ubah/<?php echo e($jadwal->id); ?>" method="POST" enctype='multipart/form-data'>
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="customFile">File Pengumuman</label>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="customFile" value="<?php echo e(asset('files/jadwal/' . $jadwal->jadwal ? $jadwal->jadwal : '')); ?>" name="jadwal" required>
                                            <label class="custom-file-label" for="customFile" data-label="tugas_update"><?php echo e($jadwal->jadwal ? $jadwal->jadwal : ''); ?></label>
                                            <div class="form-text">Diizinkan PDF, maksimal 4 MB</div>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary">Perbarui</button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <p>Belum ada jadwal pelajaran. Silakan Upload jadwal pelajaran</p>
                                <form action="/administrator/jadwal-pelajaran/tambah" method="POST" enctype='multipart/form-data'>
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="customFile">Jadwal Pelajaran</label>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="customFile" name="jadwal" required>
                                            <label class="custom-file-label" for="customFile">Pilih file Jadwal Pelajaran</label>
                                            <div class="form-text">Diizinkan PDF, maksimal 4 MB</div>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary">Publish</button>
                                    </div>
                                </form>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/js/pickers/flatpickr/flatpickr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('/admin/assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasi-ele\resources\views/admin/pages/jadwal-pelajaran.blade.php ENDPATH**/ ?>