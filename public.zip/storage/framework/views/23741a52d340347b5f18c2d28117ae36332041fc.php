
<?php $__env->startSection('title', "Data Mata Pelajaran"); ?>
<?php $__env->startSection('vendor-css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/vendors.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/pickers/flatpickr/flatpickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/core/menu/menu-types/vertical-menu.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/plugins/forms/pickers/form-flat-pickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">

            <div class="content-header-left col-md-9 col-12 mb-2">
              <div class="row breadcrumbs-top">
                <div class="col-12">
                  <h2 class="content-header-title float-left mb-0"><a href="<?php echo e(route('data-mapel')); ?>">Data  Mata Pelajaran</a></h2>
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item active">
                      <?php echo e($mapel->mapel); ?>

                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          
           <div class="card">
              <form action="/administrator/data-mata-pelajaran/ubah/<?php echo e($mapel->id); ?>" method="POST">

                <?php echo csrf_field(); ?>
                <div class="modal-body">
                  <?php if($errors->any()): ?>
                      <div class="alert alert-danger">
                          <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>
                  <?php endif; ?>
                  <label>Nama Mata Pelajaran</label>
                  <div class="form-group">
                    <input type="text" placeholder="Bahasa Indonesia" class="form-control" name="mapel" value="<?php echo e(old('mapel') ? old('mapel') : $mapel->mapel); ?>" required />
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="submit" id="btn-simpan" class="btn btn-primary">Simpan</button>
                </div>
              </form>
           </div>
          
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-vendor-js'); ?>
<script src="<?php echo e(asset('/admin/vendors/js/pickers/flatpickr/flatpickr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script src="<?php echo e(asset('/admin/assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasi-ele\resources\views/admin/pages/data-mapel-lihat.blade.php ENDPATH**/ ?>