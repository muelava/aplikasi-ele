
<?php $__env->startSection('title', "Kelola Materi"); ?>
<?php $__env->startSection('vendor-css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/vendors.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/pickers/flatpickr/flatpickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/core/menu/menu-types/vertical-menu.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/plugins/forms/pickers/form-flat-pickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">

            <div class="content-header-left col-md-9 col-12 mb-2">
              <div class="row breadcrumbs-top">
                <div class="col-12">
                  <h2 class="content-header-title float-left mb-0">Materi</h2>
                </div>
              </div>
            </div>
            
          </div>

          
            <div class="row" id="table-hover-row">
                <div class="col-12">

                    <div class="card">

                      <?php if(session()->has('success')): ?>
                      <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                      <?php endif; ?>
                      <?php $__errorArgs = ['dok_materi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="card-header justify-content-start">
                            <button class="btn btn-primary mr-2" data-toggle="modal" data-target="#modal-tambah-materi"><i data-feather="plus"></i> Tambah Materi</button>
                        </div>
                        <div class="card-header">
                          <h6>Cari Berdasarkan Kelas & Materi:</h6>
                        </div>
                        <form action="/guru/materi" method="GET" class="card-header justify-content-start d-flex pt-0" style="gap:1rem">
                          <div class="form-group col-12 col-md-3">
                            <select class="form-control" name="kelas">
                              <option value="">Semua Kelas</option>
                              <?php $__currentLoopData = $kelass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($kelas->kelas); ?>" <?php echo e(request('kelas') === $kelas->kelas ? 'selected': ''); ?>><?php echo e($kelas->kelas); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                          <div class="form-group col-8 col-md">
                            <input type="search" class="form-control" name="materi" placeholder="Nama Materi.." value="<?php echo e(request('materi')); ?>">
                          </div>
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary">Cari</button>
                          </div>
                        </form>
                        <hr>
                        <!-- Stats Vertical Card -->
                        <div class="row mx-0 px-2 mb-3">
                          <?php if($card_materis->count() > 0): ?>
                            <?php $__currentLoopData = $card_materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card_materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="javascript:" class="col-xl-2 col-md-4 col-sm-6 shadow" title="Klik info untuk lebih lanjut" onclick="card_materi('<?php echo e($card_materi->materi_id); ?>', '<?php echo e($card_materi->materi); ?>', '<?php echo e($card_materi->jenjang); ?>', '<?php echo e($card_materi->kelas); ?>', '<?php echo e($card_materi->mapel); ?>', '<?php echo e($card_materi->deskripsi); ?>', '<?php echo e($card_materi->dok_materi); ?>', '<?php echo e($card_materi->mata_pelajaran_id); ?>', '<?php echo e($card_materi->kelas_id); ?>')">
                              <div class="card text-left">
                                <small class="d-block text-secondary mt-1 text-right" style="font-size:0.8rem"><?php echo e($card_materi->materi_created_at ? \Carbon\Carbon::parse($card_materi->materi_created_at)->diffForHumans() : '-'); ?></small>
                                <div class="card-body p-1">
                                  <div class="avatar bg-light-primary p-50 mb-1">
                                    <div class="avatar-content">
                                      <i data-feather="file-text" class="font-medium-5"></i>
                                    </div>
                                  </div>
                                  <h5 class="font-weight-bolder text-uppercase"><?php echo e($card_materi->jenjang); ?> (<?php echo e($card_materi->kelas); ?>)</h5>
                                  <p class="mb-0"><?php echo e($card_materi->mapel); ?></p>
                                  <small class="card-text text-dark mb-0"><?php echo e(Str::words($card_materi->materi, 2, ' ..')); ?></small>
                                </div>
                              </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                            <p class="h5 mx-auto">Tidak Ada Materi <b><?php echo e(request('materi')); ?></b></p>
                          <?php endif; ?>
                        </div>
                        <!--/ Stats Vertical Card -->
                        
                      </div>

                </div>
            </div>
          
    </div>
</div>

<!-- Modal tambah -->
<div class="modal fade text-left" id="modal-tambah-materi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true" >
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel33">Tambah Materi</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/guru/materi/tambah" enctype='multipart/form-data' method="POST">
        
        <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          <label>Mata Pelajaran</label>
          <div class="form-group">
            <select class="form-control" name="mata_pelajaran_id" required>
              <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($mapel->id); ?>"><?php echo e($mapel->mapel); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <label>Kelas</label>
          <div class="form-group">
            <select class="form-control" name="kelas_id" required>
              <?php $__currentLoopData = $kelass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->kelas); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <label>Nama Materi</label>
          <div class="form-group">
            <input type="text" placeholder="Pythagoras" class="form-control" name="materi" required value="<?php echo e(old('materi')); ?>" />
          </div>
          <label>Deskripsi</label>
          <div class="form-group">
            <textarea class="form-control" name="deskripsi" cols="30" rows="10" placeholder="Berikan keterangan.." required><?php echo e(old('deskripsi')); ?></textarea>
          </div>
          <div class="form-group">
            <label for="customFile">Dokumen Materi</label>
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="customFile" name="dok_materi" required>
              <label class="custom-file-label" for="customFile">Pilih file</label>
              <div class="form-text">Diizinkan PDF, maksimal 4 MB</div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- /Modal tambah -->

<!-- Modal view -->
<div class="modal fade text-left" id="modal-view-materi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true" >
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel33"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <div>
          <div class="jenjang mb-1">
            <small class="d-block text-secondary" style="margin-bottom: 0.2rem">Jenjang</small>
            <p class="h6 text-uppercase"></p>
          </div>
          <div class="kelas mb-1">
            <small class="d-block text-secondary" style="margin-bottom: 0.2rem">Kelas</small>
            <p class="h6 text-uppercase"></p>
          </div>
          <div class="mapel mb-1">
            <small class="d-block text-secondary" style="margin-bottom: 0.2rem">Mata Pelajaran</small>
            <p class="h6"></p>
          </div>
          <div class="materi mb-1">
            <small class="d-block text-secondary" style="margin-bottom: 0.2rem">Nama Materi</small>
            <p class="h6"></p>
          </div>
          <div class="deskripsi mb-1">
            <small class="d-block text-secondary" style="margin-bottom: 0.2rem">Deskripsi</small>
            <p class="h6"></p>
          </div>
          <div class="dok_materi mb-1">
            <small class="d-block text-secondary" style="margin-bottom: 0.2rem">File Materi</small>
            <p class="h6"></p>
          </div>
          <hr>
          <div class="d-flex" style="gap:1rem">
            <a href="javascript:" id="btn-ubah" class="btn btn-sm bg-light-warning"><i data-feather="edit"></i> Ubah</a>
            <a href="javascript:" id="btn-diskusi" class="btn btn-sm bg-light-primary"><i data-feather="message-circle"></i> Diskusi</a>
            <a href="javascript:" id="btn-tugas" class="btn btn-sm bg-light-success"><i data-feather="list"></i> Tugas</a>
            <a href="javascript:" id="btn-hapus" class="btn btn-sm bg-light-danger ml-auto"><i data-feather="trash"></i> Hapus</a>
          </div>
        </div>
        
      </div>
    </div>
  </div>
</div>
<!-- /Modal view -->

<!-- Modal ubah -->
<div class="modal fade text-left" id="modal-ubah-materi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true" >
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel33">Ubah Materi</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="#" enctype='multipart/form-data' method="POST">
        
        <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          <label>Mata Pelajaran</label>
          <div class="form-group">
            <select class="form-control" name="mata_pelajaran_id" required>
              <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($mapel->id); ?>"><?php echo e($mapel->mapel); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <label>Kelas</label>
          <div class="form-group">
            <select class="form-control" name="kelas_id" required>
              <?php $__currentLoopData = $kelass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->kelas); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <label>Nama Materi</label>
          <div class="form-group">
            <input type="text" placeholder="Pythagoras" class="form-control" name="materi" required />
          </div>
          <label>Deskripsi</label>
          <div class="form-group">
            <textarea class="form-control" name="deskripsi" cols="30" rows="10" placeholder="Berikan keterangan.." required></textarea>
          </div>
          <div class="form-group">
            <label for="customFile">Dokumen Materi</label>
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="customFile" name="dok_materi" required>
              <label class="custom-file-label" for="customFile">Pilih file</label>
              <div class="form-text">Diizinkan PDF, maksimal 4 MB</div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- /Modal ubah -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-vendor-js'); ?>
<script src="<?php echo e(asset('/admin/vendors/js/pickers/flatpickr/flatpickr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script src="<?php echo e(asset('/admin/assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('guru.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasi-ele\resources\views/guru/pages/materi.blade.php ENDPATH**/ ?>