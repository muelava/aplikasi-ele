
<?php $__env->startSection('title', "Diskusi"); ?>
<?php $__env->startSection('vendor-css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/vendors.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/pickers/flatpickr/flatpickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/core/menu/menu-types/vertical-menu.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/plugins/forms/pickers/form-flat-pickr.min.css')); ?>">

<meta name="_token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">

            <div class="content-header-left col-md-9 col-12 mb-2">
              <div class="row breadcrumbs-top">
                <div class="col-12">
                  <h2 class="content-header-title float-left mb-0"><a href="<?php echo e(route('guru-materi')); ?>"><?php echo e($materi->kelas->kelas); ?></a></h2>
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item active">
                      <a href="<?php echo e(route('guru-materi')); ?>"><?php echo e($materi->mata_pelajaran->mapel); ?></a>
                    </li>
                    <li class="breadcrumb-item active">
                      <a href="<?php echo e(route('guru-materi')); ?>"><?php echo e($materi->materi); ?></a>
                    </li>
                    <li class="breadcrumb-item active">
                      Diskusi
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          
            <div class="row" id="table-hover-row">
                <div class="col-12">

                  
                  <div class="card">
                    <div class="card-header">
                      <h3><?php echo e($materi->materi); ?></h3>
                    </div>

                    <div class="card-body">

                      <small class="d-block">Deskripsi</small>
                      <h5><?php echo e($materi->deskripsi); ?></h5>
                      
                      <small class="d-block mt-2">File</small>
                      <a class="btn text-primary pl-0" target="_blank" href="<?php echo e(asset('files/materies/'.$materi->dok_materi)); ?>">Download Materi</a>

                      <small class="d-block mt-2">Tugas</small>
                      <?php if($materi->tugas->count() > 0): ?>
                      <a class="btn text-primary pl-0" href="<?php echo e(asset('guru/materi/tugas/'.$materi->id)); ?>">Lihat Tugas</a>
                      <?php else: ?>
                      <p>Belum ada tugas</p>
                      <?php endif; ?>

                    </div>
                  </div>
                  

                  <?php if($diskusis->count() > 0): ?>
                  <h4 class="text-center mb-2 mt-3">(<?php echo e($diskusis->count()); ?>) Diskusi</h4>
                  <?php else: ?>
                  <h4 class="text-center mb-2 mt-3">Tidak Ada Diskusi</h4>
                  <?php endif; ?>
                  <button class="btn btn-sm btn-primary mb-2" data-toggle="modal" data-target="#modal-tambah-diskusi" ><i data-feather="plus"></i> Diskusi</button>

                  
                  <?php if($diskusis->count() > 0): ?>

                    <?php $__currentLoopData = $diskusis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskusi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="diskusi card mb-1" diskusi="<?php echo e($diskusi->id); ?>">
                      <div class="card-header">
                        <div>
                          <small class="font-weight-bold"><?php echo e($diskusi->guru ? $diskusi->guru->nama : $diskusi->siswa->nama); ?></small>
                          •
                          <small><?php echo e($diskusi->created_at->diffForHumans()); ?></small>
                        </div>
                        <small class="d-block text-capitalize" style="margin-top: 0.25rem"><?php echo e($diskusi->guru ? $diskusi->guru->role : $diskusi->siswa->role); ?></small>
                      </div>

                      <div class="card-body">
                        <p><?php echo e($diskusi->komentar); ?></p>
                        <button class="btn text-primary" onclick="reply_button(this)">Balas</button>
                      </div>
                    </div>

                    <?php
                    $tbl_sub_diskusi = App\Models\SubDiskusi::where('diskusi_id', $diskusi->id)->orderBy('id', 'desc')->get();
                    ?>

                    <?php if($tbl_sub_diskusi->count() > 0): ?>
                      <?php $__currentLoopData = $tbl_sub_diskusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_diskusi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="sub-diskusi card ml-3">
                            <div class="card-header">
                              <div>
                                <small class="font-weight-bold"><?php echo e($sub_diskusi->guru ? $sub_diskusi->guru->nama : $sub_diskusi->siswa->nama); ?></small>
                                •
                                <small><?php echo e($sub_diskusi->created_at->diffForHumans()); ?></small>
                              </div>
                              <small class="d-block text-capitalize" style="margin-top: 0.25rem"><?php echo e($sub_diskusi->guru ? $sub_diskusi->guru->role : $sub_diskusi->siswa->role); ?></small>
                            </div>
                            <div class="card-body">
                              <p><?php echo e($sub_diskusi->komentar); ?></p>
                            </div>
                          </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                  <?php endif; ?>
                  

                </div>
            </div>
          
    </div>
</div>

<!-- Modal tambah -->
<div class="modal fade text-left" id="modal-tambah-diskusi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true" >
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel33">Tambah Diskusi</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/guru/materi/diskusi/tambah/<?php echo e($materi->id); ?>" method="POST">
        
        <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          <label>Diskusi materi</label>
          <h4 class="mb-3"><?php echo e($materi->materi); ?></h4>
          <label>Komentar</label>
          <div class="form-group">
            <textarea class="form-control <?php $__errorArgs = ['komentar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="komentar" cols="30" rows="10" placeholder="Tulis komentar.." required><?php echo e(old('komentar')); ?></textarea>
            <?php $__errorArgs = ['komentar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- /Modal tambah -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-vendor-js'); ?>
<script src="<?php echo e(asset('/admin/vendors/js/pickers/flatpickr/flatpickr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script src="<?php echo e(asset('/admin/assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('guru.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasi-ele\resources\views/guru/pages/materi-diskusi.blade.php ENDPATH**/ ?>