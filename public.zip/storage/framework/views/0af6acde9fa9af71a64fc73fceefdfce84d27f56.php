
<?php $__env->startSection('title', 'Login | Selamat Datang Kembali'); ?>

<?php $__env->startSection('container'); ?>
<div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
    
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="img-background" src="/img/hero (2).jpg" alt="" >
        <div class="container d-flex">
          <div class="carousel-caption lihat-cara-login text-start">
            
          </div>
        </div>
      </div>
     
    </div>
   
  </div>

  <div class="container">
  <h4 class="fw-bold text-center my-5" id="form-login">Silakan Login</h4>
   <div class="row justify-content-center">

     
     <form action="/login" method="POST" class="col-lg-4 text-center">
      <?php if(session()->has('success')): ?>
      <div class="alert alert-success"><?php echo e(session('success')); ?></div>
      <?php endif; ?>

      <?php echo csrf_field(); ?>


      <?php if(session()->has('loginError')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <?php echo e(session('loginError')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>    

      <div class="mb-3 form-floating">
        <input type="text" id="email" class="form-control form-control-sm rounded-pill <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="NIS/Email" name="email" value="<?php echo e(old('email')); ?>" autofocus>
        <label for="email">NIS/Email</label>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
          <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3 form-floating">
        <input type="password" id="password" class="form-control form-control-sm rounded-pill <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password">
        <label for="password">Password</label>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
              <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <button type="submit" class="btn my-3 btn-premiere text-white fw-bold px-5">Login</button>
    </form>

    <small class="text-center"><a href="#">Lupa Password?</a></small>
  </div>
  
  <section class="row justify-content-center" id="cara-login">
    <h4 class="fw-bold text-center mb-4">Cara Login</h4>
    <div class="col-md-5">
      <img class="w-100" src="/img/cara-login-guru.png" alt="">
    </div>
    <div class="col-md-5">
      <img class="w-100" src="/img/cara-login-siswa.png" alt="">
    </div>
  </section>
</div>

<script>
  $(document).ready(function(){
  $('html,body').animate({
    scrollTop: $('#form-login').offset().top - 80
  }, 800, 'easeInOutExpo');
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasi-ele\resources\views/login/index.blade.php ENDPATH**/ ?>