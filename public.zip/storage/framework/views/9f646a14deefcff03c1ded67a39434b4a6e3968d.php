
<?php $__env->startSection('title', 'Data Kelas'); ?>
<?php $__env->startSection('vendor-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/vendors/css/pickers/flatpickr/flatpickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/core/menu/menu-types/vertical-menu.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/admin/css/plugins/forms/pickers/form-flat-pickr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-header row">

                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0"><a href="<?php echo e(route('pengumuman')); ?>">Pengumuman</a></h2>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active">
                                    <?php echo e($pengumuman->judul); ?>

                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="card">
                <form action="/administrator/pengumuman/ubah/<?php echo e($pengumuman->id); ?>" method="POST" enctype='multipart/form-data'>

                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <?php if($errors->any()): ?>
                            <div id="error-modal-tambah-pengumuman" class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label>Judul</label>
                            <input type="text" placeholder="Judul" class="form-control" name="judul" required value="<?php echo e(old('judul') ? old('judul') : $pengumuman->judul); ?>" />
                        </div>
                        <div class="form-group">
                            <label>Deskripsi</label>
                            <textarea class="form-control" name="deskripsi" id="" rows="5" placeholder="deskripsi"><?php echo e(old('judul') ? old('judul') : $pengumuman->deskripsi); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="customFile">File Pengumuman</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="customFile" value="<?php echo e(asset('files/pengumuman/' . $pengumuman->file ? $pengumuman->file : '')); ?>" name="file">
                                <label class="custom-file-label" for="customFile" data-label="tugas_update"><?php echo e($pengumuman->file ? $pengumuman->file : ''); ?></label>
                                <div class="form-text">Diizinkan PDF, maksimal 4 MB</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-vendor-js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/js/pickers/flatpickr/flatpickr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('/admin/assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasi-ele\resources\views/admin/pages/pengumuman-ubah.blade.php ENDPATH**/ ?>